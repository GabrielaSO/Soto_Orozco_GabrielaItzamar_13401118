
package com.example.giso.gestionobra;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Empleados extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empleados);
    }
}
