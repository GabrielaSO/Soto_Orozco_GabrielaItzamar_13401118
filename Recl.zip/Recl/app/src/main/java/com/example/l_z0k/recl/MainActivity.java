package com.example.l_z0k.recl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.l_z0k.recl.ui.adapter.Datos;
import com.example.l_z0k.recl.ui.adapter.DiseaseAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private DiseaseAdapter mAdapter;
    private List<Datos> datos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView = findViewById(R.id.my_recycler_view);

        // Usar esta línea para mejorar el rendimiento
        // si sabemos que el contenido no va a afectar
        // el tamaño del RecyclerView
        mRecyclerView.setHasFixedSize(true);

        // Nuestro RecyclerView usará un linear layout manager
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);

        // Asociamos un adapter (ver más adelante cómo definirlo)
        mAdapter= new DiseaseAdapter(this);
        mRecyclerView.setAdapter(mAdapter);
        datos = new ArrayList<>();
        datos.add(new Datos("Gabriela Soto", "ITICS",14401052, R.drawable.a123));
        datos.add(new Datos("Elizabeth Orozco", "ITICS",14401053, R.drawable.user));
        datos.add(new Datos("Jose Garcia", "ITICS",14401054, R.drawable.people));
        datos.add(new Datos("Jose Garcia", "ISC",14401054, R.drawable.people));
        datos.add(new Datos("Jose Garcia", "ISC",14401054, R.drawable.people));
        datos.add(new Datos("Jose Garcia", "ISC",14401054, R.drawable.people));
        mAdapter.setmDataSet(datos);
        
  }
}
