package com.example.giso.gestionobra;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button nuevaObra, nuevoEmpleado,obras, empleados, clientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nuevaObra = findViewById(R.id.nObra);
        nuevoEmpleado = findViewById(R.id.nEmpleado);
        obras = findViewById(R.id.obras);
        empleados = findViewById(R.id.empleados);
        clientes = findViewById(R.id.clientes);

        nuevaObra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nuevaObraForm = new Intent(v.getContext(),FormNuevaObra.class);
                startActivity(nuevaObraForm);
            }
        });
        nuevoEmpleado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent nuevoEmpleadoForm = new Intent(v.getContext(),FormNuevoEmpleado.class);
                startActivity(nuevoEmpleadoForm);
            }
        });
        obras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obra = new Intent(v.getContext(),Obras.class);
                startActivity(obra);
            }
        });
        clientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cliente= new Intent(v.getContext(),Clientes.class);
                startActivity(cliente);
            }
        });
        empleados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent empleado = new Intent(v.getContext(),Empleados.class);
                startActivity(empleado);
            }
        });
    }
}