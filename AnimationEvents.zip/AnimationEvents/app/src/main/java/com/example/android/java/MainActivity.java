package com.example.android.java;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    private ImageView imagen;
    private RelativeLayout canvas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imagen= (ImageView) findViewById(R.id.faceIcon);
        canvas = (RelativeLayout) findViewById(R.id.animationCanvas);
    }

    public void bounce(View v) {

        int screenHeight = canvas.getHeight();
        int targetY = screenHeight - imagen.getHeight();

        ObjectAnimator animator = ObjectAnimator.ofFloat(
                imagen, "y", 0, targetY)
                .setDuration(5000);
        animator.setInterpolator(new BounceInterpolator());
        animator.start();
    }

    public void acelerate (View v){
        int screenHeight = canvas.getHeight();
        int targetY = screenHeight - imagen.getHeight();
        ObjectAnimator animator = ObjectAnimator.ofFloat(
                imagen, "y", 0, targetY)
                .setDuration(5000);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.start();

    }

    public void decelerate(View v){
        int screenHeight = canvas.getHeight();
        ObjectAnimator animator = ObjectAnimator.ofFloat(
                imagen, "y", 800, 0)
                .setDuration(5000);

        animator.setInterpolator(new AccelerateInterpolator());
        animator.start();
    }

    public void cycle(View v){
        CycleInterpolator cycleInterpolator = new CycleInterpolator(20f);
        ViewPropertyAnimator anim = imagen.animate();
        anim.alpha(0);
        anim.setDuration(3000);
        anim.setInterpolator(cycleInterpolator);
    }

}
