package com.example.l_z0k.recl.ui.adapter;

public class Datos {
    String name;
    String carrera;
    int noctrl;
    int photoId;

    public Datos(String name, String carrera,int noctrl, int photoId) {
        this.name = name;
        this.carrera = carrera;
        this.noctrl = noctrl;
        this.photoId = photoId;
    }

}